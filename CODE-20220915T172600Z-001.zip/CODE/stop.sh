#!/bin/bash
python3 Stoplight.py &